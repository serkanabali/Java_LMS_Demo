package lms;

public class Main {

    public static void main(String[] args) {
        System.out.println("Program başladı!");

        Ogrenci ogr0 = new Ogrenci();
        ogr0.ad = "Adem Arda";
        ogr0.soyad = "AKKAYA";
        ogr0.kimlikNo = 123456789;
        ogr0.ogrenciNo = 210000001;

        Ogrenci ogr1 = new Ogrenci();
        ogr1.ad = "Metin";
        ogr1.soyad = "NİF";
        ogr1.ogrenciNo = 210000002;

        Ogrenci ogr2 = new Ogrenci();
        ogr2.ad = "Emre";
        ogr2.soyad = "ALTUN";
        ogr2.ogrenciNo = 210000004;

        ogr0.dersCalis();
        ogr1.dersCalis();
        ogr2.dersCalis();

        Egitmen hoca1 = new Egitmen();
        hoca1.ad = "Volkan";
        hoca1.soyad = "ÖZTÜRK";
        hoca1.unvan = "Öğr. Gör.";
        hoca1.kullaniciAdi = "vozturk";

        hoca1.dersAnlat();

        Ders ders1 = new Ders("Nesne Tabanlı Programlama I", "BBP118");

        ders1.derseHocaAta(hoca1);
        ders1.derseOgrenciEkle(ogr0);
        ders1.derseOgrenciEkle(ogr1);
        ders1.derseOgrenciEkle(ogr2);

        ders1.listeYazdir();

//        Ders ders2 = new Ders("Programlama Temelleri II","BBP110");        
//        System.out.println("Ders kodu =>>>> "+ders1.dersKodu);
//        System.out.println("Ders kodu =>>>> "+ders2.dersKodu);
    }
}
