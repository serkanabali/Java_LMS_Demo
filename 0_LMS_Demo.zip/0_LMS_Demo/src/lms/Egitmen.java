package lms;

public class Egitmen extends Kisi {

    String kullaniciAdi;
    String unvan;

    void dersAnlat() {
        System.out.println(ad + " " + soyad + " isimli hoca ders anlattı.");
    }

    @Override
    public String toString() {
        return unvan + " " + ad + " " + soyad;
    }

}
