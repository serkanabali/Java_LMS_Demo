package lms;

import java.util.ArrayList;

public class Ders {

    String dersAdi;
    String dersKodu;

    private Egitmen egitmen;
    ArrayList<Ogrenci> ogrenciListesi;

    public Ders(String dersAdi, String dersKodu) {
        this.dersAdi = dersAdi;
        this.dersKodu = dersKodu;
        ogrenciListesi = new ArrayList<Ogrenci>();
    }

    public void derseHocaAta(Egitmen e) {
        if (e != null) {
            egitmen = e;
        }
    }

    public void derseOgrenciEkle(Ogrenci o) {
        System.out.println(dersAdi + " dersine eklenen " + (ogrenciListesi.size() + 1) + ". Öğrenci Bilgileri = " + o);
        ogrenciListesi.add(o);
    }

    public void listeYazdir() {
        System.out.println("\n******* LİSTE ********");
        System.out.println("Ders Adı-Kodu \t= " + this);
        System.out.println("Dersin Hocası \t= " + this.egitmen);
        System.out.println("Öğrenci Sayısı\t= " + this.ogrenciListesi.size());
        System.out.println("------------");
        for (Ogrenci ogr : ogrenciListesi) {
            System.out.println("\t* " + ogr);
        }
    }

    @Override
    public String toString() {
        return dersAdi + " (" + dersKodu + ")";
    }

}
