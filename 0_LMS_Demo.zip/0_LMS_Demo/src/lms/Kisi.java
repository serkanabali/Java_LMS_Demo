
package lms;

public class Kisi {    
    String ad;
    String soyad;
    long kimlikNo;
    
    void oturumAc(){       
        System.out.println("Kullancı oturum açtı..");
    }  
}
