
package lms;

public class Ogrenci extends Kisi{
    
    int ogrenciNo;
    String bolum;
    
    void dersCalis(){
        System.out.println(ad+" "+soyad+" isimli öğrenci ders çalıştı.");
    } 
    
    public String toString(){
        return ad+" "+soyad+" ("+ogrenciNo+")";
    }
    
}
